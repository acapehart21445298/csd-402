/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rockpaperscissors;

/**
 *
 * @author arrin
 */
import java.util.Random;
import java.util.Scanner;

public class RockPaperScissors {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random random = new Random();
        int computerChoice = random.nextInt(3) + 1;
        
        Scanner input = new Scanner(System.in);

        System.out.print("Enter 1 for Rock, 2 for Paper, or 3 for Scissors: ");
        int userChoice = input.nextInt();

        while (userChoice < 1 || userChoice > 3) {
            System.out.print("Invalid choice. Please enter 1, 2, or 3: ");
            userChoice = input.nextInt();
}
        
        String computerSelection = "";

        if (computerChoice == 1) {
            computerSelection = "Rock";
        } else if (computerChoice == 2) {
            computerSelection = "Paper";
        } else {
            computerSelection = "Scissors";
        }

        System.out.println("Computer chose: " + computerSelection);
        
        String userSelection = "";

        if (userChoice == 1) {
            userSelection = "Rock";
        } else if (userChoice == 2) {
            userSelection = "Paper";
        } else {
            userSelection = "Scissors";
        }

        System.out.println("You chose: " + userSelection);
        
        if (computerChoice == userChoice) {
            System.out.println("It's a tie!");
        } else if (userChoice == 1 && computerChoice == 3) {
            System.out.println("You win! Rock beats Scissors.");
        } else if (userChoice == 2 && computerChoice == 1) {
            System.out.println("You win! Paper beats Rock.");
        } else if (userChoice == 3 && computerChoice == 2) {
            System.out.println("You win! Scissors beats Paper.");
        } else {
            System.out.println("Computer wins!");
        }
    }
    
}
